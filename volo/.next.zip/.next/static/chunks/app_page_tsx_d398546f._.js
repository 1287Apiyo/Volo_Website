(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_d398546f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_d398546f._.js",
  "chunks": [
    "static/chunks/node_modules_574430e9._.js",
    "static/chunks/sections_ece21427._.js"
  ],
  "source": "dynamic"
});
