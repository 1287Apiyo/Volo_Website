(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_terms_page_c5d71938.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_terms_page_c5d71938.js",
  "chunks": [
    "static/chunks/app_terms_page_597016be.js"
  ],
  "source": "dynamic"
});
