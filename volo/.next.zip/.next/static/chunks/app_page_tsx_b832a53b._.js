(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_b832a53b._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_b832a53b._.js",
  "chunks": [
    "static/chunks/node_modules_9b867200._.js",
    "static/chunks/sections_ece21427._.js"
  ],
  "source": "dynamic"
});
