(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/[root of the server]__98144f0b._.css",
    "static/chunks/node_modules_framer-motion_dist_es_d360d841._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_dabdd57a._.js",
    "static/chunks/components_75db8cf2._.js"
  ],
  "source": "dynamic"
});
