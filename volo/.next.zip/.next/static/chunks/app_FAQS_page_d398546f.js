(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_FAQS_page_d398546f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_FAQS_page_d398546f.js",
  "chunks": [
    "static/chunks/node_modules_next_15251bc2._.js",
    "static/chunks/app_FAQS_page_e3abfb60.js"
  ],
  "source": "dynamic"
});
