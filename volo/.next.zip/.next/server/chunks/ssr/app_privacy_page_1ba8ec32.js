module.exports = {

"[project]/app/privacy/page.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, d: __dirname } = __turbopack_context__;
{
// app/privacy/page.js
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
"use client";
;
;
const Privacy = ()=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "min-h-screen flex flex-col items-center justify-center bg-black text-white px-6 py-16",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-3xl",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-4xl font-bold text-yellow-500 text-center mb-8",
                    children: "VOLO Technologies privacy policy."
                }, void 0, false, {
                    fileName: "[project]/app/privacy/page.js",
                    lineNumber: 10,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    id: "terms",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-semibold text-yellow-400 mb-4",
                            children: "VOLO Privacy Policy"
                        }, void 0, false, {
                            fileName: "[project]/app/privacy/page.js",
                            lineNumber: 16,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-2xl font-semibold text-yellow-400 mb-4",
                            children: "Effective Date: 01/March/2025"
                        }, void 0, false, {
                            fileName: "[project]/app/privacy/page.js",
                            lineNumber: 19,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-lg text-gray-300 leading-relaxed",
                            children: "VOLO is committed to protecting your privacy and ensuring that your personal data is handled responsibly. This Privacy Policy explains how we collect, use, store, and protect your information when you use our taxi-hailing services in Kenya."
                        }, void 0, false, {
                            fileName: "[project]/app/privacy/page.js",
                            lineNumber: 23,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                            className: "border-gray-700 my-8"
                        }, void 0, false, {
                            fileName: "[project]/app/privacy/page.js",
                            lineNumber: 28,
                            columnNumber: 13
                        }, this),
                        [
                            {
                                title: "1. Information We Collect",
                                content: "We collect and process the following types of information:",
                                list: [
                                    "Personal Information: Name, phone number, email address, profile picture, and payment details.",
                                    "Location Data: Real-time GPS location to facilitate ride requests and navigation.",
                                    "Ride Information: Trp history, route details, and fare amounts.",
                                    "Device Information: IP address, operating system, and app usage data.",
                                    "Communications: Any messages or support requests sent to VOLO."
                                ]
                            },
                            {
                                title: "2. How We Use Your Information",
                                content: "We use your data for the following purposes:",
                                list: [
                                    "To provide, operate, and improve VOLO services.",
                                    "To match passengers with drivers and facilitate ride requests.",
                                    "To process payments and issue receipts.",
                                    "To enhance safety and detect fraudulent activities.",
                                    "To provide customer support and resolve disputes.",
                                    "To comply with legal requirements and law enforcement requests."
                                ]
                            },
                            {
                                title: "3. Data Sharing and Disclosure",
                                content: "We do not sell your personal data. However, we may share your information:",
                                list: [
                                    "With drivers to facilitate ride requests.",
                                    "With payment processors for secure transactions.",
                                    "With law enforcement or regulatory authorities when required by law.",
                                    "With service providers who help us operate the platform."
                                ]
                            },
                            {
                                title: "4. Data Security",
                                content: "We implement strong security measures to protect your data, including encryption and access controls. However, no system is 100% secure, and users should also take precautions to safeguard their accounts."
                            },
                            {
                                title: "5. User Rights and Choices",
                                content: "You have the right to:",
                                list: [
                                    "Access, update, or delete your personal data.",
                                    "Opt out of marketing communications.",
                                    "Restrict or object to certain data processing activities.",
                                    "Request a copy of your personal information."
                                ]
                            },
                            {
                                title: "6. Non-Discrimination Policy",
                                content: "VOLO strictly prohibits any form of discrimination based on race, gender, religion, disability, sexual orientation, nationality, or any other protected characteristic. Users (both passengers and drivers) must treat each other with respect. Any reports of discriminatory behavior will be investigated, and appropriate action will be taken, including potential suspension or removal from the platform."
                            },
                            {
                                title: "7. Data Retention",
                                content: "We retain your personal data for as long as necessary to fulfill the purposes outlined in this policy. Once data is no longer needed, we securely delete or anonymize it."
                            },
                            {
                                title: "8. Third-Party Services",
                                content: "Our app may contain links to third-party services or payment platforms. VOLO is not responsible for the privacy practices of these external services."
                            },
                            {
                                title: "9. Policy Updates",
                                content: "We may update this Privacy Policy periodically. Users will be notified of significant changes, and continued use of VOLO services implies acceptance of the updated policy."
                            }
                        ].map((section, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-6 text-gray-400",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xl font-semibold",
                                        children: section.title
                                    }, void 0, false, {
                                        fileName: "[project]/app/privacy/page.js",
                                        lineNumber: 102,
                                        columnNumber: 17
                                    }, this),
                                    section.content && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-lg leading-relaxed mt-2",
                                        children: section.content
                                    }, void 0, false, {
                                        fileName: "[project]/app/privacy/page.js",
                                        lineNumber: 104,
                                        columnNumber: 19
                                    }, this),
                                    section.list && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "text-lg list-disc pl-6 mt-2",
                                        children: section.list.map((item, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                children: item
                                            }, i, false, {
                                                fileName: "[project]/app/privacy/page.js",
                                                lineNumber: 109,
                                                columnNumber: 23
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/app/privacy/page.js",
                                        lineNumber: 107,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, index, true, {
                                fileName: "[project]/app/privacy/page.js",
                                lineNumber: 101,
                                columnNumber: 15
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/privacy/page.js",
                    lineNumber: 15,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("hr", {
                    className: "border-gray-700 my-8"
                }, void 0, false, {
                    fileName: "[project]/app/privacy/page.js",
                    lineNumber: 116,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-center text-gray-500 text-base",
                    children: [
                        "If you have any questions, please contact us at",
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            href: "@/sections/Contact",
                            className: "text-yellow-400 underline",
                            children: "VOLO Support"
                        }, void 0, false, {
                            fileName: "[project]/app/privacy/page.js",
                            lineNumber: 120,
                            columnNumber: 17
                        }, this),
                        "."
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/privacy/page.js",
                    lineNumber: 118,
                    columnNumber: 15
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/privacy/page.js",
            lineNumber: 9,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/privacy/page.js",
        lineNumber: 8,
        columnNumber: 9
    }, this);
};
const __TURBOPACK__default__export__ = Privacy;
}}),

};

//# sourceMappingURL=app_privacy_page_1ba8ec32.js.map